/* $Id: solvers.h,v 1.4 2004/12/11 19:26:11 ellson Exp $ $Revision: 1.4 $ */
/* vim:set shiftwidth=4 ts=8: */

/**********************************************************
*      This software is part of the graphviz package      *
*                http://www.graphviz.org/                 *
*                                                         *
*            Copyright (c) 1994-2004 AT&T Corp.           *
*                and is licensed under the                *
*            Common Public License, Version 1.0           *
*                      by AT&T Corp.                      *
*                                                         *
*        Information and Software Systems Research        *
*              AT&T Research, Florham Park NJ             *
**********************************************************/

#ifdef __cplusplus
extern "C" {
#endif



#ifndef _SOLVERS_INCLUDE
#define _SOLVERS_INCLUDE

    extern int solve3(double *, double *);
    extern int solve2(double *, double *);
    extern int solve1(double *, double *);

#endif

#ifdef __cplusplus
}
#endif
