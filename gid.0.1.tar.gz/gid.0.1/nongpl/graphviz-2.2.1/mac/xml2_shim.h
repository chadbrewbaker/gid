#ifdef __cplusplus
extern "C" {
#endif

/* parser.h */
FUNCTION(xmlLineNumbersDefault)

/* tree.h */
FUNCTION(xmlGetLineNo)
FUNCTION(xmlGetNodePath)

/* xmlIO.h */
FUNCTION(xmlAllocParserInputBuffer)
FUNCTION(xmlFreeParserInputBuffer)
FUNCTION(xmlParserInputBufferGrow)
FUNCTION(xmlParserInputBufferPush)

/* xmlreader.h */
FUNCTION(xmlFreeTextReader)
FUNCTION(xmlNewTextReader)
FUNCTION(xmlTextReaderCurrentNode)
FUNCTION(xmlTextReaderIsEmptyElement)
FUNCTION(xmlTextReaderLocatorLineNumber)
FUNCTION(xmlTextReaderMoveToElement)
FUNCTION(xmlTextReaderMoveToNextAttribute)
FUNCTION(xmlTextReaderName)
FUNCTION(xmlTextReaderNodeType)
FUNCTION(xmlTextReaderRead)
FUNCTION(xmlTextReaderSetErrorHandler)
FUNCTION(xmlTextReaderValue)

#ifdef __cplusplus
}
#endif
