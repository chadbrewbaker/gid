/* $Id: grammar.h,v 1.6 2004/12/11 19:26:12 ellson Exp $ $Revision: 1.6 $ */
/* vim:set shiftwidth=4 ts=8: */

/**********************************************************
*      This software is part of the graphviz package      *
*                http://www.graphviz.org/                 *
*                                                         *
*            Copyright (c) 1994-2004 AT&T Corp.           *
*                and is licensed under the                *
*            Common Public License, Version 1.0           *
*                      by AT&T Corp.                      *
*                                                         *
*        Information and Software Systems Research        *
*              AT&T Research, Florham Park NJ             *
**********************************************************/

#ifdef __cplusplus
extern "C" {
#endif

#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

#ifndef YYSTYPE
    typedef union {
	int i;
	char *str;
	struct Agnode_s *n;
    } aagstype;
# define YYSTYPE aagstype
# define YYSTYPE_IS_TRIVIAL 1
#endif
# define	T_graph	257
# define	T_node	258
# define	T_edge	259
# define	T_digraph	260
# define	T_subgraph	261
# define	T_strict	262
# define	T_edgeop	263
# define	T_list	264
# define	T_attr	265
# define	T_atom	266
# define	T_qatom	267


    extern YYSTYPE aaglval;

#endif				/* not BISON_Y_TAB_H */

#ifdef __cplusplus
}
#endif
