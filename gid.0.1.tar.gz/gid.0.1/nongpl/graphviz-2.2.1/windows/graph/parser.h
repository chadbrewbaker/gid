/* $Id: parser.h,v 1.6 2004/12/11 19:26:12 ellson Exp $ $Revision: 1.6 $ */
/* vim:set shiftwidth=4 ts=8: */

/**********************************************************
*      This software is part of the graphviz package      *
*                http://www.graphviz.org/                 *
*                                                         *
*            Copyright (c) 1994-2004 AT&T Corp.           *
*                and is licensed under the                *
*            Common Public License, Version 1.0           *
*                      by AT&T Corp.                      *
*                                                         *
*        Information and Software Systems Research        *
*              AT&T Research, Florham Park NJ             *
**********************************************************/

#ifdef __cplusplus
extern "C" {
#endif

#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

#ifndef YYSTYPE
    typedef union {
	int i;
	char *str;
	struct objport_t obj;
	struct Agnode_t *n;
    } agstype;
# define YYSTYPE agstype
# define YYSTYPE_IS_TRIVIAL 1
#endif
# define	T_graph	257
# define	T_digraph	258
# define	T_strict	259
# define	T_node	260
# define	T_edge	261
# define	T_edgeop	262
# define	T_symbol	263
# define	T_qsymbol	264
# define	T_subgraph	265


    extern YYSTYPE aglval;

#endif				/* not BISON_Y_TAB_H */

#ifdef __cplusplus
}
#endif
